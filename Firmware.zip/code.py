import board
from kmk.kmk_keyboard import KMKKeyboard
from kmk.keys import KC
from kmk.scanners.keypad import KeysScanner
from kmk.modules.layers import Layers

keyboard = KMKKeyboard()

# 1. Enable Layers
keyboard.modules.append(Layers())

# 2. Define Pins (9, 10, 11)
PINS = [board.D8, board.D9, board.D10]

keyboard.matrix = KeysScanner(
    pins=PINS,
    value_when_pressed=False,
)

# 3. Define the Keymap
# Layer 0: [Undo, Layer 1 Toggle, Redo]
# Layer 1: [Left Arrow, (nothing), Right Arrow]
keyboard.keymap = [
    # LAYER 0 (Default)
    [
        KC.LCTL(KC.Z), 
        KC.MO(1),      # MO(1) = Momentary Layer 1 (Active ONLY while held)
        KC.LCTL(KC.Y)
    ],
    # LAYER 1 (Active only when Pin 10 is held)
    [
        KC.LEFT, 
        KC.TRNS,       # Transparent (keeps the layer active)
        KC.RIGHT
    ]
]

if __name__ == '__main__':
    keyboard.go()